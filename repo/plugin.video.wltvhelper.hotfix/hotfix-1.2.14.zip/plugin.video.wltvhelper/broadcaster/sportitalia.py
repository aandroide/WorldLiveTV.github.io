# -*- coding: utf-8 -*-

import requests
from lib import scrapers, utils, logger
from lib.broadcaster_result import BroadcasterResult

HOST = "https://www.sportitalia.it/"

CHANNELS = {
    "sihd": "si_hd",
    "calcio": "si_calcio",
    "primaveratv": "primaveratv",
    "laziostyle": "lazio_style"
}

def play(search):
    res = BroadcasterResult()

    headers = utils.getBrowserHeaders(host=HOST)
    chId = CHANNELS[search]

    data = requests.get(HOST, headers=headers).text
    pattern = fr'<a\s+[^>]*?href="([^"]+)"[^>]*>(?:(?!</a>).)*?<img\s+[^>]*?title="{chId}"[^>]*?>(?:(?!</a>).)*?</a>'
    urlPage = scrapers.findSingleMatch(data, pattern)

    if urlPage:
        data = requests.get(urlPage, headers=headers).text
        pattern = r'file:\s*"([^"]+)"'
        url = scrapers.findSingleMatch(data, pattern)
    
    if url:
        res.Url = url
        res.StreamHeaders = headers
        #res.UseInputStreamAdaptive = False

    return res
